package othelloGame;

public enum GameStatus {
    NOT_STARTED, IN_PROGRESS, HAS_NO_MOVES, NO_MORE_MOVES, FULL_BOARD
}
