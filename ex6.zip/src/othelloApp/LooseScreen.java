package othelloApp;

/**
 * Created by Liora on 13-Jan-18.
 */
/*public class LooseScreen {
    public void doOneFrame(DrawSurface d, double dt) {
        if (this.lives.getValue() == 0) {
            d.setColor(Color.BLACK);
            d.fillRectangle(0, 0, 800, 600);
            d.setColor(Color.WHITE);
            d.drawText(200, 330, "\u2620", 430);
            d.drawText(260, 425, "GAME OVER", 50);
            d.drawText(310, 475, "YOUR SCORE:", 25);
            d.drawText(330, 560, "" + this.score.getValue() , 80);
        } else {
            d.setColor(Color.BLACK);
            d.fillRectangle(0, 0, 800, 600);
            d.setColor(Color.WHITE);
            d.fillRectangle(10, 10, 780, 580);
            d.setColor(this.generateRandomColor());
            d.fillCircle(400, 300, 240);
            d.setColor(Color.WHITE);
            d.fillCircle(400, 300, 200);
            d.setColor(new Color(223, 150, 240));
            d.setColor(Color.BLACK);
            d.drawText(260, 275, "YOU WON!!!", 50);
            d.drawText(310, 325, "YOUR SCORE:", 25);
            d.drawText(330, 410, "" + this.score.getValue() , 80);
        }
}*/
