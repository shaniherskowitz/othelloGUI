package othelloGame;

public enum Tile
{
    X, O, EMPTY
}
